// Copyright (C) 2023 (Catherine Hosage Norman, Christopher Norman, Module 3 Solutions, LLC)
// Markdown conversion excerpted from Showdown, a JavaScript Markdown to HTML converter,
// based on the original works by John Gruber.
//
// Reader.js is published under the Free Software Foundation LGPL. This stylesheet is free software;
// It can be redistributed and/or modified under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License,
// or (at your option) any later version. This codet is distributed WITHOUT ANY WARRANTY;
// without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU Lesser General Public License for more details. For a copy of the GNU Lesser General
// Write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
// Or find a copy at http://fsf.org.
//
// Revisions:
//      10/2023: Initial version commissioned by the FDA

/** lots of info is stored like <element value='something important'>
 *  REALLY don't want to type Element.getAttribute('value') over and over,
 *  this puts it in a getter, i.e. Element.value
 */
Object.defineProperty(Element.prototype, "value", {
  get: function () {
    return this.getAttribute("value");
  },
});
let resultBundle;
const xmlSerializer = new XMLSerializer()
/**
 * Because of CORS the css has to be a string
 */
const style = `td {
  padding-left:1em;
  padding-bottom: 0.5em;
}
div.polymorph{
  padding-left:1em;
}
div#narrative{
  margin-left: 8px;
}
header p{
  color: black;
  padding-left: 1em;
  font-size: small;
}
img.narrative{
  height: auto;
  width: 100%;
  object-fit: contain;
}
`;
const style32p10=`table.productTable,table.productTable th,table.productTable td{
  border: 1px solid black;
  border-collapse: collapse;
  padding: 0.5em;
}
table.productTable td{
  text-align: right;
}
.productTable td.partName{
  text-align: left;
}
.productTable td.ingredientName{
  text-align: left;
}
.productTable td.function{
  text-align: center;
}
.productTable td.center{
  text-align: center;
}
.productTable td.left{
  text-align: left;
}
table.productTable .total {
  border-top: 2px solid black;
  font-weight: bold;
}
table{
  margin-bottom: 1em;
}
`;
const styleSpecification = `table.specificationTable,table.specificationTable th,table.specificationTable td{
  border: 1px solid black;
  border-collapse: collapse;
  padding: 0.5em;
}
`

const mdConverter = new showdown.Converter();


function changeHandler(evt) {
  evt.stopPropagation();
  evt.preventDefault();

  // FileList object.
  var files = evt.target.files;

  var file = files[0];

  var fileReader = new FileReader();

  fileReader.onloadstart = function (progressEvent) {
    resetLog();
    appendLog("onloadstart!");
    var msg =
      "File Name: " +
      file.name +
      "<br>" +
      "File Size: " +
      file.size +
      "<br>" +
      "File Type: " +
      file.type;
    appendLog(msg);
  };

  fileReader.onload = function (progressEvent) {
    appendLog("onload!");
    var stringData = fileReader.result;
    console.log(stringData);
    appendLog(" ---------------- File Content Preview----------------: ");
    appendLog(" See console for complete loaded bundle file (F12)");
    appendLog(stringData);
  };

  fileReader.onloadend = function (progressEvent) {
    appendLog("onloadend!");
    // FileReader.EMPTY, FileReader.LOADING, FileReader.DONE
    appendLog("readyState = " + fileReader.readyState);
    cleanOut(fileReader.result);
  };

  fileReader.onerror = function (progressEvent) {
    appendLog("onerror!");
    appendLog("Has Error!");
  };

  // Read file asynchronously.
  fileReader.readAsText(file, "UTF-8"); // fileReader.result -> String.
}

function resetLog() {
  document.getElementById("log-div").innerHTML = "";
}

function appendLog(msg) {
  document.getElementById("log-div").innerHTML += "<br>" + msg;
}
const addHTML = (...data) => {
  document.getElementById("js-output").innerHTML += data.flat().join("");
};

/**
 *
 * @typedef {import('./narrative.js')} Narrative
 */

function cleanOut(fileString) {
  const xmlDocument = new DOMParser().parseFromString(fileString, "application/xhtml+xml");
  appendLog(" ---------------- Converted XML Objects ----------------: ");
  console.log(xmlDocument);
  console.log(xmlDocument.attributes)
  // xsl looks for text elements; if they're not in Composition then they get set to empty,
  // if it is in Composition it gets a status and an empty div whose contents will be set with
  // javascript
  const xsl = `<?xml version='1.0' encoding='UTF-8'?>
    <xsl:stylesheet version='2.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform' xmlns:xs='http://www.w3.org/2001/XMLSchema' xmlns:fn='http://www.w3.org/2005/xpath-functions' xmlns:fhir='http://hl7.org/fhir' xmlns:msxsl='urn:schemas-microsoft-com:xslt' xmlns:utex='text-utility-function' exclude-result-prefixes='msxsl xml xs fn utex fhir'>
        <xsl:output method='xml' encoding='UTF-8'/>
        <xsl:output omit-xml-declaration='yes' indent='yes'/>
        <xsl:preserve-space elements='description valueMarkdown fhir:description fhir:valueMarkdown'/>
        <xsl:variable name='XML' select='/'/>
        <xsl:template match='@*|node()'>
            <xsl:copy>
                <xsl:apply-templates select='@*|node()'/>
            </xsl:copy>
        </xsl:template>

        <!-- If the composition has no text element, make one after the meta tag -->
        <xsl:template match="*/fhir:Composition[not(fhir:text)]/fhir:meta">
            <xsl:copy-of select="." copy-namespaces='no'/>
            <xsl:element name='text' namespace="{namespace-uri()}">
                <xsl:element name='status' namespace="{namespace-uri()}">
                    <xsl:attribute name="value">generated</xsl:attribute>
                </xsl:element>
                <xsl:element name='div' namespace="http://www.w3.org/1999/xhtml">
                    <xsl:attribute name='id'>narrative</xsl:attribute>
                </xsl:element>
            </xsl:element>
        </xsl:template>

        <!-- If a text tag has a status element in it, and it's not in Composition,
        set it to empty -->
        <xsl:template match='*/fhir:text[fhir:status]'>
            <xsl:choose>
                <xsl:when test='ancestor::fhir:Composition'>
                    <xsl:element name='text' namespace="{namespace-uri()}">
                        <xsl:element name='status' namespace="{namespace-uri()}">
                            <xsl:attribute name="value">generated</xsl:attribute>
                        </xsl:element>
                        <xsl:element name='div' namespace="http://www.w3.org/1999/xhtml">
                            <xsl:attribute name='id'>narrative</xsl:attribute>
                        </xsl:element>
                    </xsl:element>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:element name='text' namespace='{namespace-uri()}'>
                        <xsl:element name='status' namespace='{namespace-uri()}'>
                            <xsl:attribute name='value'>empty</xsl:attribute>
                        </xsl:element>
                    </xsl:element>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:template>

    </xsl:stylesheet>`;

  const parser = new DOMParser();
  const cleanfile = parser.parseFromString(xsl, "application/xhtml+xml");
  const xsltProcessor = new XSLTProcessor();
  // the behavior of xsltProcessor varies between browsers. FireFox treats the contents of
  // text elements as strings, even when created with xsl, whereas Edge treats them as
  // elements. To get consistent behavior the xslt is ran, then gets serialized, then gets
  // turned back into a document so everything is an element
  xsltProcessor.importStylesheet(cleanfile);
  const intermediate = xsltProcessor.transformToDocument(xmlDocument);
  resultBundle = parser.parseFromString(
    xmlSerializer.serializeToString(intermediate),
    "application/xhtml+xml"
  );

  appendLog(
    " See console for orginal Bundle and the bundle file with exsiting text removed. (F12) "
  );
  console.log(resultBundle);
  const bundleProfile = resultBundle
    .querySelector("Bundle>meta>profile")
    .getAttribute("value");
  appendLog(" ---------------- Document Profile ----------------: ");
  appendLog(bundleProfile);
  resultBundle.querySelector("Composition text");
  appendLog(" ---------------- Data Extraction ----------------: ");
  const narrative = new Narrative();
  const sections = resultBundle.getElementsByTagName("section");

  const sponsorRef = resultBundle.querySelector('Composition>author>reference')?.value
  if (sponsorRef){
    const sponsor = Organization.fromReference(sponsorRef)

    narrative.add(
      '<header>',
      '<p>',
      'Sponsor: ', sponsor.simpleName,
      '</p>',
      '<hr/>',
      '</header>')
  }



  // const test = resultBundle.getElementById('sectitle')
  // console.log('TEST:')
  // console.log(test)
  // console.log(resultBundle.querySelector('#sectitle'))
  // resultBundle.getElementById('sectitle').innerHTML += HeaderTitle;
  // resultBundle.getElementById('sponsor').innerHTML += sponsorName;
  switch (bundleProfile) {
    case "http://hl7.org/fhir/us/pq-cmc/StructureDefinition/cmc-ectd-document-32s10":
      //--------32S10-------------------------


      console.log("sections:");
      console.log(sections);
      narrative.add(`<style>${style}</style>`);
      // there are two sections, nomenclature and structure
      Array.from(sections).forEach((section) => {
        console.log(section);
        const title = section.querySelector("title").value;
        const code = section.querySelector("coding code").value;
        // get the ID out of the reference
        const referenceID = section.querySelector("entry reference").value;
        const definition = SubstanceDefinition.fromReference(referenceID);
        switch (code) {
          case "32S11":
            console.log("GOT TO NOMENCLATURE SECTION");
            narrative.add(`<h2>3.2.S.1.1 ${title}</h2>`);
            definition.writeNomenclatureTable(narrative);
            if (definition.polymorphs) {
              narrative.add('<div class="polymorph">');
              definition.polymorphs.forEach((polymorph) => {
                narrative.add(`<h3>Polymorph: ${polymorph.identifier}</h3>
                            <h4>Nomenclature for ${polymorph.identifier}</h4>`);
                polymorph.writeNomenclatureTable(narrative);
                if (polymorph.representations) {
                  narrative.add(
                    `<h4>Structure for ${polymorph.identifier}</h4>`
                  );
                  polymorph.writeStructureTable(narrative);
                }
              });
              narrative.add("</div>");
            }
            break;
          case "32S12":
            console.log("GOT TO STRUCTURE SECTION");
            narrative.add(`<h2>3.2.S.1.2 ${title}</h2>`);
            definition.writeStructureTable(narrative);
            break;
          default:
            console.error("Got unhandled section:", code);
            break;
        }
      });
      break;
    case "http://hl7.org/fhir/us/pq-cmc/StructureDefinition/cmc-ectd-document-32p10":
      narrative.add(`<style>${style} ${style32p10}</style>`);
      // there are two sections, nomenclature and structure
      Array.from(sections).forEach((section) => {
        console.log(section);
        const title = section.querySelector("title").getAttribute("value");
        const code = section.querySelector("coding code").getAttribute("value");
        // get the ID out of the reference
        const referenceID = section
          .querySelector("entry reference").value
        switch (code) {
          case "32P11":
            const description = DrugProductDescription.fromReference(referenceID)
            console.log(description)
            narrative.add(`<h2>3.2.P.1.1 ${title}</h2>`);
            description.write(narrative)
            break;
          case "32P12":
            narrative.add(`<h2>3.2.P.1.2 ${title}</h2>`);
            const product = FinishedProduct.fromReference(referenceID);
            console.log(product)
            product.write(narrative)
            break;
            case "32P13":
                narrative.add(`<h2>3.2.P.1.3 ${title}</h2>`);
                const containerDescription = DrugProductContainerClosure.fromReference(referenceID)
                containerDescription.write(narrative)
            break;
        }
      });
      break;
      case "http://hl7.org/fhir/us/pq-cmc/StructureDefinition/cmc-ectd-document-sp4151":
        narrative.add(`<style>${style} ${styleSpecification}</style>`)
        // Quality Specification will only ever have one section in Composition,
        // but the name of that section will change depending on what type of 
        // resource the specification is for
        Array.from(sections).forEach(section=>{
          const title = resultBundle.querySelector('Composition>title').value
          const code = section.querySelector('coding code').value
          const specificationRef = section.querySelector('entry reference').value 
          const specification = QualitySpecification.fromReference(specificationRef)
          console.log(specification)
          switch (code){
            case "32P51":
              narrative.add(`<h2>3.2.P.5.1 ${title}</h2>`)
              const product = RoutineDrugProduct.fromReference(specification.subjectReference)
              product.writeTable(narrative)
              break;
            case "32S41":
              narrative.add(`<h2>3.2.S.4.1 ${title}</h2>`)
              const substance = RoutineSubstanceDefinition.fromReference(specification.subjectReference)
              substance.writeTable(narrative)
              break;
            case "32P41":
              // EXCIPIENT
              narrative.add(`<h2>3.2.P.4.1 ${title}</h2>`)
              const excipient = ExcipientRaw.fromReference(specification.subjectReference)
              console.log(excipient)
              excipient.writeTable(narrative)
              break;
            default:
              console.error('unkown code:',code)
          }
          specification.write(narrative)
        })
      break;
      case "http://hl7.org/fhir/us/pq-cmc/StructureDefinition/cmc-ectd-document-32s23":
        narrative.add(`<style>${style} ${styleSpecification}</style>`)
        const title =resultBundle.querySelector('Composition>title').value
        narrative.add(`<h2>3.2.S.2.3 ${title}</h2>`)

        // const table = new BasicTable()
        // table.addHeader('Title','Type')
        // Array.from(sections).forEach(section=>{
        //   const title = 
        // })
        Array.from(sections).forEach(section=>{
          console.log(section)
          const specificationRef = section.querySelector('entry reference').value;
          const specification = QualitySpecification.fromReference(specificationRef)
          
          //table.addRow(specification.title,specification.type)  
          const excipient = ExcipientRaw.fromReference(specification.subjectReference)
          narrative.add(`<h3>${specification.title}</h3>`)
          excipient.writeTable(narrative)
          specification.write(narrative)
        })
      break;
    default:
      console.error("unknown profile:", bundleProfile);
  } //last paren before print
  console.log(resultBundle.getElementById("narrative"));
  document.getElementById("js-output").innerHTML = narrative.html;
  console.log(narrative.html);

  resultBundle.querySelector("Composition > text > div").innerHTML =
    new XMLSerializer().serializeToString(parser.parseFromString(narrative.html,'text/html'))
  console.log(parser.parseFromString(narrative.html, "text/html"));
  //--------32P10-------------------------
  //--------copy to text area for review and save-------------------------
  var serializedXml = new XMLSerializer().serializeToString(resultBundle);
  //document.getElementById('xml-textarea').value = "hello";
  document.getElementById("xml-textarea").value = serializedXml;
  document.getElementById("xml-textarea").readOnly = true;

  function saveFileAs() {
    if ((promptFilename = prompt("Save file as", ""))) {
      var textBlob = new Blob([serializedXml], { type: "application/xml" });

      var downloadLink = document.createElement("a");
      downloadLink.download = promptFilename;
      downloadLink.innerHTML = "Download File";
      downloadLink.href = window.URL.createObjectURL(textBlob);
      downloadLink.click();
    }
  }
  document.getElementById("save-button").onclick = saveFileAs;
}
