class SubstanceDefinition_Name {
  /**
   *
   * @param {Element} nameXML
   */
  constructor(nameXML) {
    this.name = nameXML.querySelector("name").value;
    if (this.name.includes('&')) console.log(nameXML.querySelector('name'))
    this.type = nameXML.querySelector("type > coding > display").value;
    this.preferred =
      nameXML.querySelector("preferred")?.value === "true" ? true : false;
  }
}
class SubstanceDefinition_Representation {
  #TYPES = Object.freeze({
    DOCUMENT: "document",
    NORMAL: "normal",
  });
  contentType;
  title;
  base64Data;
  // a hidden type incase documents
  // and regular representations need
  // to be distinguished
  type;
  constructor(representation, format) {
    this.representation = representation;
    this.format = format;
    this.type = this.#TYPES.NORMAL;
  }
  /**
   * take a document reference and pull
   * the type, data, and title out and
   * into the Representation
   * @param {string} reference
   */
  set attatchment(reference) {
    // get the ID out of the reference
    const uuid = reference.split("/")[1] ??
    reference.split('urn:uuid:')[1]??reference;
    const doc = resultBundle
      // find the id tag with the value attribute set to the id
      .querySelector(`id[value='${uuid}']`)
      // get the document that the id tag is part of
      .closest("DocumentReference");
    // create a mapping between tag names and the properties
    const tagToPropertyMap = new Map([
      ["contentType", "contentType"],
      ["data", "base64Data"],
      ["title", "title"],
    ]);
    // loop over the tags in <attachment>
    doc.querySelectorAll("content > attachment > *").forEach((tag) => {
      // assign the properties whatever value is in the value attribute
      // i.e contentType, data, title
      this[tagToPropertyMap.get(tag.tagName)] = tag.value;
    });
    this.type = this.#TYPES.DOCUMENT;
  }
  static fromXML(element) {
    const repRep = element.querySelector(
      "representation > representation"
    )?.value;
    const repCodeDisplay = element.querySelector(
      "representation > type > coding > display"
    )?.value;
    const repObj = new SubstanceDefinition_Representation(repRep, repCodeDisplay);
    const repReference = element.querySelector(
      "representation > document > reference"
    )?.value;
    // if there is a reference to document, pass it to the setter
    // to go parse the document
    if (repReference) {
      repObj.attatchment = repReference;
    }
    return repObj;
  }
}

class SubstanceDefinition extends Resource {
  constructor(xml) {
    super();
    this.identifier = xml.querySelector("identifier>value")?.value;
    this.classification = xml.querySelector(
      "classification>coding>display"
    )?.value;
    const mfgReference = xml.querySelector("manufacturer>reference")?.value;
    if (mfgReference)
      this.manufacturer = Organization.fromReference(mfgReference);
    const supplierReference = xml.querySelector("supplier>reference")?.value;
    if (supplierReference)
      this.supplier = Organization.fromReference(supplierReference);
    const representations = Array.from(
      xml.querySelectorAll("structure>representation")
    ).map((repxml) => SubstanceDefinition_Representation.fromXML(repxml));
    const names = Array.from(xml.querySelectorAll(":scope>name")).map(
      (nameXml) => new SubstanceDefinition_Name(nameXml)
    );
    if (names.length) this.names = names;
    if (representations.length) this.representations = representations;
    const molecularWeight = xml.querySelector("molecularWeight>amount");
    if (molecularWeight)
      this.molecularWeight = {
        value: molecularWeight.querySelector("value").value,
        unit: molecularWeight.querySelector("unit").value,
      };
    this.uniiCode = xml.querySelector(":scope>code>code>coding>code")?.value;
    this.molecularFormula = xml.querySelector(
      "structure>molecularFormula"
    )?.value;
    const polymorph = Array.from(
      xml.querySelectorAll("substanceDefinitionReference>reference")
    ).map((ref) => SubstanceDefinition.fromReference(ref.value));
    if (polymorph.length) this.polymorphs = polymorph;
    // source material stuff
    const sourceMaterial= xml.querySelector('sourceMaterial')
    if (sourceMaterial){
        this.sourceMaterial={}
        this.sourceMaterial.type = sourceMaterial.querySelector('type display').value
        this.sourceMaterial.genus =sourceMaterial.querySelector('genus text')?.value
        this.sourceMaterial.species = sourceMaterial.querySelector('species text')?.value
        this.sourceMaterial.part = sourceMaterial.querySelector('part text')?.value
        this.sourceMaterial.countryOfOrigin = sourceMaterial.querySelector('countryOfOrigin display')?.value
    }
  }
  get sourceMaterialString (){
    if (this.sourceMaterial?.genus){
        let returnString = ""+this.sourceMaterial.genus
        if (this.sourceMaterial.species) returnString+= " "+ this.sourceMaterial.species
        if (this.sourceMaterial.part) returnString += ": "+this.sourceMaterial.part
        return returnString
    } else return null
  }
  get preferredTerm() {
    const preferred = this.names?.filter(n=>n.preferred)[0]?.name
    const gsrs = this.names?.filter(n=>n.type=='GSRS Preferred')[0]?.name
    const common = this.names?.filter(n=>n.type=='Common')[0]?.name
    const first = this.names[0]?.name
    switch (true) {
        // if there is a preferred term use that (i.e it had a preferred element
        // with a 'true' value for its value attribute)
        case !!preferred:
            return preferred
        // else if there is a gsrs term use that
        case !!gsrs:
            return gsrs
        // else if there is a common term use that
        case !!common:
            return common
        // else just use whatever comes first
        case !!first:
            return first
        // else throw an error
        default:
            throw new Error('there are no names?')
    }
  }
  writeStructureTable(narrative) {
    narrative.add(`<table>`);
    if (this.molecularFormula)
      narrative.add(
        `<tr><td>Molecular Formula:</td><td>${this.molecularFormula}</td></tr>`
      );
    narrative.add(
      this.representations.map((rep) => {
        if (rep.type == "normal") {
          return `<tr>
                    <td>${rep.format}:</td>
                    <td>${rep.representation}</td>
                    </tr>`;
        }
      }),
      this.representations
        .filter((r) => r.type == "document")
        .map((rep) => {
          if (
            ["image/png", "image/jpeg", "image/svg+xml"].includes(
              rep.contentType
            )
          ) {
            return `<tr><td>Structure Graphic: </td>
                        <td><img class="narrative" src="data:${rep.contentType};base64,${rep.base64Data}"/></td></tr>`;
          } else
            return `<tr><td>file:</td>
                    <td><a href="data:${rep.contentType};base64,${rep.base64Data}" download="${rep.title}">${rep.title}</a></td></tr>`;
        }),
      "</table>"
    );
  }
  writeNomenclatureTable(narrative) {
    narrative.add(
      `<table>`,
      this.names.map(
        (name) =>
          `<tr>
                    <td>${name.type}:</td>
                    <td>${name.name}</td>
                    </tr>`
      )
    );
    if (this.uniiCode) {
      narrative.add(`<tr><td>UNII Code:</td><td>${this.uniiCode}</td></tr>`);
    }
    if (this.molecularWeight) {
      narrative.add(
        `<tr><td>Molecular Weight: </td><td>${this.molecularWeight.value}${this.molecularWeight.unit}</td></tr>`
      );
    }
    narrative.add(`</table>`);
  }
}