class QualitySpecification extends Resource{
    goals = {}
    constructor(xml){
        super();
        this.identifier = xml.querySelector(':scope>identifier value')?.value;
        this.version = xml.querySelector(':scope>version').value
        this.versionDate = xml.querySelector(':scope>date').value
        this.status = xml.querySelector(':scope>status').value
        this.title= xml.querySelector(':scope>title').value
        this.subTitle=xml.querySelector(':scope>subtitle')?.value
        const extensions = Array.from(xml.querySelectorAll(':scope>extension'))
        this.subjectReference = xml.querySelector('subjectReference reference').value
        extensions.forEach(extension=>{
            const url = extension.getAttribute('url')
            switch (url){
                case "http://hl7.org/fhir/us/pq-cmc/StructureDefinition/pq-additional-info-extension":
                    this.additionalInfo =
                    mdConverter.makeHtml(
                        extension.querySelector('valueMarkdown').value
                    )
                    break;
                case "http://hl7.org/fhir/us/pq-cmc/StructureDefinition/pq-specification-type-extension":
                    this.type = extension.querySelector('valueCodeableConcept display').value
                    break;
                default:
                    console.error('unkown extension url:',url)
            }
        })
        this.approvalStatus = xml.querySelector('useContext>valueCodeableConcept display').value
        this.approvalDate = xml.querySelector(':scope>approvalDate')?.value
        Array.from(xml.querySelectorAll(':scope>goal')).forEach(
            goalXML=>{
                const goal = new QualitySpecification_Goal(goalXML)
                this.goals[goal._id] = goal
            }
        )
        this.tests = Array.from(xml.querySelectorAll(':scope>action')).map(
            testXML=>new QualitySpecification_Test(testXML)
        ).sort((a,b)=>{
            Number(a.order)-Number(b.order)
        })
        // stages and groups just have goal Ids, need to make a circular reference to the goals
        // in the specification class
        this.tests.forEach(test=>{
            switch (test._type){
                case "Single Stage":
                    test.goalIDs.forEach(id=>{
                        test.goals[id] = this.goals[id]
                    })
                    test.groups.forEach(group=>{
                        group.goalIDs.forEach(id=>{
                            group.goals[id] = this.goals[id]
                            group.subtests.forEach(subtest=>{
                                subtest.goalIDs.forEach(id=>{
                                    subtest.goals[id] = this.goals[id]
                                })
                            })
                        })
                    })
                case "Multiple Stage":
                    test.stages.forEach(stage=>{
                        stage.goalIDs.forEach(id=>{
                            stage.goals[id]=this.goals[id]
                            stage.subtests.forEach(subtest=>{
                                subtest.goalIDs.forEach(id=>{
                                    subtest.goals[id]=this.goals[id]
                                })
                            })
                        })
                    })
            }
        })
    }
    
    write(narrative){
        console.log(this.tests)
        const table= new BasicTable({style:'margin-bottom: 1em'})
        const rowTag = new Tag('tr')
        const tableHeader = new Tag('th',{'colspan':'2'})
        tableHeader.add('Specification Details')
        rowTag.add(tableHeader)
        table.add(rowTag);
        table.addRow('Version:',this.version)
        table.addRow('Version Date:',this.versionDate)
        if (this.approvalStatus) table.addRow('Approval Status:',this.approvalStatus)
        if (this.approvalDate) table.addRow('Approval Date:',this.approvalDate)
        if (this.type) table.addRow('Type:',this.type)
        narrative.add(table.html)
        const criteriaTable = new BasicTable({
            //style:'border: 1px solid black',
            class:'specificationTable'
        })
        criteriaTable.addHeader('Category','Test Name','Acceptance Criteria (Usage *)','Analytical Procedure','Procedure Name','Type','Comments')
        this.tests.forEach(test=>{
            const categoryCell = new Tag('td')
            categoryCell.add(test.category)
            if (test.subCategory) categoryCell.add(new Tag('br'),test.subCategory)
                
            // CRITERION LIST
            const criterionList = new Tag('ul',{style:'list-style-type: none;margin:0;padding:0;'})
            switch (test._type){
                case "Single Stage":
                    if (Object.values(test.goals).length>0){
                        Object.values(test.goals).forEach(goal=>{
                            const goalTag = new Tag('li');
                                goalTag.add(...goal.criterionRow)
                                criterionList.add(goalTag)
                        })
                    }
                    if (test.groups.length>0){
                        test.groups.forEach(group=>{
                            const groupTag = new Tag('li');
                            groupTag.add(group.title)
                            if (Object.values(group.goals).length>0){
                                const criteriaList = new Tag ('ul');
                                Object.values(group.goals).forEach(goal=>{
                                    const goalTag = new Tag('li');
                                        goalTag.add(...goal.criterionRow)
                                        criteriaList.add(goalTag)
                                })
                                groupTag.add(criteriaList)
                            }
                            if (group.subtests.length>0){
                                const subtestList = new Tag('ul')
                                group.subtests.forEach(subtest=>{
                                    const subtestTag = new Tag('li');
                                    subtestTag.add(subtest.title)
                                    const criteriaList = new Tag ('ul');
                                    Object.values(subtest.goals).forEach(goal=>{
                                        const goalTag = new Tag('li');
                                        goalTag.add(...goal.criterionRow)
                                        criteriaList.add(goalTag)
                                    })
                                    subtestTag.add(criteriaList)
                                    subtestList.add(subtestTag)
                                })
                                groupTag.add(subtestList)
                            }
                            criterionList.add(groupTag)
                        })
                    }
                case "Multiple Stage":
                    test.stages.forEach(stage=>{
                        const stageTag = new Tag('li')
                        stageTag.add(stage.name)
                        if (stage.title) stageTag.add(': ',stage.title)
                        if (stage.subtests.length>0){
                            const subtestList = new Tag('ul')
                            stage.subtests.forEach(subtest=>{
                                const subtestTag = new Tag('li');
                                subtestTag.add(subtest.title)
                                const criteriaList = new Tag ('ul');
                                Object.values(subtest.goals).forEach(goal=>{
                                    const goalTag = new Tag('li');
                                    goalTag.add(...goal.criterionRow)
                                    criteriaList.add(goalTag)
                                })
                                subtestTag.add(criteriaList)
                                subtestList.add(subtestTag)
                            })
                            stageTag.add(subtestList)
                        }
                        if (Object.values(stage.goals).length>0){
                            const criteriaList = new Tag ('ul');
                            Object.values(stage.goals).forEach(goal=>{
                                const goalTag = new Tag('li');
                                    goalTag.add(...goal.criterionRow)
                                    criteriaList.add(goalTag)
                            })
                            stageTag.add(criteriaList)
                        }
                        criterionList.add(stageTag)
                    })
            }
            criteriaTable.addRow(categoryCell,test.title,criterionList,test.analyticalProcedure,test.referenceToProcedure,test.methodOrigin,test.additionalInfo)
        })
        narrative.add(criteriaTable.html)
        const asterixText = new Tag('p',{class:'footer'})
        asterixText.add('* R = Release, S = Stability')
        narrative.add(asterixText.html)
    }
}
class QualitySpecification_Goal {
    constructor (xml){
        this._id = xml.getAttribute('id');
        this.description = xml.querySelector('description text').value
        const addresses = Array.from(xml.querySelectorAll('addresses'))
        addresses.forEach(address=>{
            const code = address.querySelector('display').value.toLowerCase()
            switch (code){
                case 'release':
                    this.release = true;
                    break;
                case 'stability':
                    this.stability = true;
                    break;
                default:
                    console.error('unknown address:',code)
            }
        })
        this.targets = Array.from(xml.querySelectorAll('target')).map(
            targetXML=>new QualitySpecification_Target(targetXML)
        )
    }
    
    get string(){
        return this.description
    }
    get criterionRow(){
        const parentDiv = new Tag('div',{style:'display:flex'})
        const leftTag = new Tag('div',{style:'flex: 9; margin-right:1em'})
        leftTag.add(this.string)
        const rightTag = new Tag('div',{style:'flex-shrink:0'})
        const addresses = []
        if (this.release) addresses.push('R')
        if (this.stability) addresses.push('S')
        rightTag.add(`(${addresses.join(' ')})`)
        parentDiv.add(leftTag,rightTag)
        return [parentDiv]
    }
}
class QualitySpecification_Target{
    #types = Object.freeze({
        Quantity:'quantity',
        String:'string',
        Range:'range',
        Integer:'integer'
    })
    _type;
    constructor(xml){
        const detailQuantity= xml.querySelector('detailQuantity')
        const detailInteger=xml.querySelector('detailInteger')
        const detailCodeableConcept=xml.querySelector('detailCodeableConcept')
        const detailRange = xml.querySelector('detailRange')
        switch (true){
            case (!!detailQuantity):
                this.detail = Quantity.fromXML(detailQuantity)
                this.detail.interpretationCode = detailQuantity.querySelector('extension display')?.value
                this._type = this.#types.Quantity
                break;
            case (!!detailInteger):
                this.detail = detailInteger.value
                this._type = this.#types.Integer
                break;
            case (!!detailRange):
                this.detail = FHIR_Range.fromXML(detailRange)
                this.detail.low.interpretationCode = detailRange.querySelector('low extension display')?.value
                this.detail.high.interpretationCode = detailRange.querySelector('high extension display')?.value
                this._type = this.#types.Range
                break;
            case (!!detailCodeableConcept):
                this.detail = {
                    value: detailCodeableConcept.querySelector('text').value,
                    interpretationCode: detailCodeableConcept.querySelector('display')?.value
                }
                this._type = this.#types.String
                break;
            default:
                throw new Error('no detail in Target?')
        }
    }
    get string(){
        switch (this._type){
            case 'string':
                return this.detail.value
            case 'integer':
                return this.detail
            case 'quantity':
                if (this.detail.interpretationCode) return this.detail.interpretationCode+this.detail.string
                else return this.detail.string
            case 'range':
                const {
                    detail:{
                        low:{
                            interpretationCode:lowCode,
                            string:lowString
                        },
                        high:{
                            interpretationCode:highCode,
                            string:highString
                        }
                    }
                } = this
                const low = lowCode?lowCode+lowString:lowString
                const high = highCode?highCode+highString:highString
                return low+', '+high
            default:
                console.error('No Target Type?')
                return ""
        }
    }
}
class QualitySpecification_Test{
    #types = Object.freeze({
        Single:'Single Stage',
        Multi: 'Multiple Stage'
    })
    goals = {}
    stages = []
    groups = []
    constructor(xml){
        this._id = xml.getAttribute('id')
        const singleStage = xml.querySelector(':scope>prefix')?.value
        console.log ("STAGE STATUS:")
        console.log(singleStage)
        if (singleStage) this._type = this.#types.Single
        else this._type = this.#types.Multi
        this.order = xml.querySelector(':scope>extension valueDecimal').value
        this.title = xml.querySelector(':scope>title')?.value
        this.linkId = xml.querySelector(':scope>linkId')?.value
        this.additionalInfo = xml.querySelector(':scope>description')?.value
        //this.relativeRetentionTime = xml.querySelector(':scope>extension valueDecimal')?.value
        this.methodOrigin = xml.querySelector(':scope>code display')?.value
        this.analyticalProcedure = xml.querySelector(':scope>code text')?.value??""
        Array.from(xml.querySelectorAll(':scope>reason'))
        .forEach(reason=>{
            const index = Number(reason.querySelector('extension valueInteger').value)
            const code = reason.querySelector('coding display').value
            if (index===1) this.category = code
            else if (index===2) this.subCategory = code
            else throw new Error(`unknown category index: ${index}`)
        })
        this.referenceToProcedure = xml.querySelector('documentation label')?.value
        switch (this._type){
            case "Single Stage":
                this.goalIDs = Array.from(xml.querySelectorAll(':scope>goalId')).map(goalIdXML=>goalIdXML.value)
                this.groups = Array.from(xml.querySelectorAll(":scope>action")).map(
                    group=>new QualitySpecification_Group(group)
                ).sort((a,b)=>Number(a.order)-Number(b.order))
                break;
            case "Multiple Stage":
                this.stages = Array.from(xml.querySelectorAll(':scope>action')).map(
                    stage => new QualitySpecification_Stage(stage)
                ).sort((a,b)=>Number(a.order)-Number(b.order))
                break;
            default:
                throw new Error ('test is not single or multi stage?')
        }
    }
    get goals(){
        
        return this.stages.map(stage=>[
            stage.goals,
            stage.groups.map(group=>group.goals)
        ]).flat(Infinity)
    }
}
class QualitySpecification_Subtest {
    goals ={}
    constructor(xml){
        this.order = xml.querySelector(':scope>extension valueDecimal').value
        this.title = xml.querySelector(':scope>title')?.value
        this.additionalInfo = xml.querySelector(':scope>description')?.value
        this.goalIDs = Array.from(xml.querySelectorAll(":scope>goalId")).map(goalIdXML=>goalIdXML.value)
    }
}
class QualitySpecification_Group extends QualitySpecification_Subtest{
    constructor(xml){
        super(xml)
        this.subtests = Array.from(xml.querySelectorAll(':scope>action')).map(
            subtest=>new QualitySpecification_Subtest(subtest)
        ).sort((a,b)=>Number(a.order)-Number(b.order))
    }
}
class QualitySpecification_Stage extends QualitySpecification_Group{
    constructor(xml){
        super(xml)
        this.name = xml.querySelector(':scope>prefix').value
    }
}
