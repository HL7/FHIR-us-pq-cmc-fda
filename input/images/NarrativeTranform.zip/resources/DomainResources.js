class MedicinalProductDefinition extends Resource {
    constructor(xml) {
      super();
      // there can be two names, proprietary and non-proprietary,
      // differentiated by name>type>coding>code
      const names = Array.from(xml.querySelectorAll(":scope>name"));
      names.forEach((name) => {
        const type = name.querySelector("type coding code").value;
        switch (type) {
          case "NON":
            this.nonProprietaryName =
              name.querySelector("productName").value;
            break;
          case "PROP":
            this.proprietaryName = name.querySelector("productName").value;
            break;
          default:
            console.error("unknown name type:", type);
            break;
        }
      });
      // CONTAINER CLOSURE SPECIFIC
      this.containerType = xml.querySelector(
        'extension[url="containerType"] display'
      )?.value;
      this.closureType = xml.querySelector(
        'extension[url="closureType"] display'
      )?.value;
      this.containerDescription = xml.querySelector(
        'extension[url="description"] valueMarkdown'
      )?.value;
      const depictionReference = xml.querySelector(
        'extension[url="depiction"] valueReference'
      )?.value;
      if (depictionReference)
        this.depiction = Base64Document.fromReference(depictionReference);
      // PRODUCT DESCRIPTION SPECIFIC
      this.description = xml.querySelector(":scope>description")?.value;
      this.doseForm = xml.querySelector(
        "combinedPharmaceuticalDoseForm>coding>display"
      )?.value;
      this.route = xml.querySelector("route>coding>display")?.value;
      this.copackagedProducts = Array.from(
        xml.querySelectorAll("crossReference product>reference")
      ).map((reference) =>
        MedicinalProductDefinition.fromReference(reference.value)
      );
    }
  }