/**
 * the base resource, has methods for finding the element
 * by reference
 */
class Resource {
    /**
     * finds an element representing a resource by its ID
     * @param {String} referenceID the id or reference to a resource
     * @returns {Element}
     */
    static findById(referenceID) {
      // if it hase the resource type prepended, remove it
      const id = referenceID.split("/")[1] ?? 
      referenceID.split('urn:uuid:')[1] ?? // if it is a urn, remove the urn prefix
      referenceID;
      // find the resource Element with this id as an attribute
      return resultBundle
        .querySelector(`id[value="${id}"]`)
        .closest("resource > *");
    }
    static fromReference(reference) {
      return new this(this.findById(reference));
    }
  }