class DrugProductDescription extends MedicinalProductDefinition {
    /**
     *
     * @param {Narrative} narrative
     */
    write(narrative) {
      narrative.add("<table>");
      if (this.proprietaryName) narrative.add(
        `<tr><td>Proprietary Name:</td><td>${this.proprietaryName}</td></tr>`
      )
      narrative.add(`<tr><td>Non-Proprietary Name:</td><td>${this.nonProprietaryName}</td></tr>`)
      if (this.doseForm) narrative.add(
        `<tr><td>Dose Form:</td><td>${this.doseForm}</td></tr>`
      )
      if (this.route) narrative.add(
        `<tr><td>Route:</td><td>${this.route}</td></tr>`
      )
      narrative.add('</table>')
      if (this.description) {
        narrative.add('<div class="markdown">')
        narrative.add(`<p>Description:</p>`)
        narrative.add(mdConverter.makeHtml(this.description))
        narrative.add('</div>')
      }
    }
}
class DrugProductContainerClosure extends MedicinalProductDefinition{
    /**
     * 
     * @param {Narrative} narrative 
     */
    write(narrative){
        narrative.add('<table>')
        if (this.containerType) narrative.add(`<tr><td>Container Type</td><td>${this.containerType}</td></tr>`)
        if (this.closureType) narrative.add(`<tr><td>Closure Type:</td><td>${this.closureType}</td></tr>`)
        if (this.depiction)  this.depiction.writeRow(narrative,'Depiction:')
        narrative.add('</table>')
        if (this.containerDescription) {
            narrative.add('<div class="markdown">')
            narrative.add(`<p>Description:</p>`)
            narrative.add(mdConverter.makeHtml(this.containerDescription))
            narrative.add('</div>')
        } 
    }
}
class FinishedProduct extends Resource {
    /**
     * 
     * @param {Element} xml 
     */
    constructor(xml){
        super(xml);
        this.identifier = xml.querySelector(':scope>identifier value')?.value;
        this.status = xml.querySelector(':scope>status').value;
        this.doseForm = xml.querySelector('manufacturedDoseForm display').value;
        
        // loop over all the properties, and when the type matches a switch
        // case, set the appropriate property
        const properties=xml.querySelectorAll(':scope>property');
        Array.from(properties).forEach(property=>{
            const type = property.querySelector('type code').value
            switch (type){
                case 'OvrRelsProf':
                    this.overallReleaseProfile = property
                    .querySelector('valueCodeableConcept display')
                    .value
                    break;
                case 'OvrRelsMech':
                    this.overallReleaseMechanism = property
                    .querySelector('valueCodeableConcept display')
                    .value
                    break;
                case 'CoatInd':
                    this.coatingIndicator = property
                    .querySelector('valueBoolean')
                    .value
                    break;
                case 'TabLayCnt':
                    this.layerCount = Quantity.fromXML(
                        property.querySelector('valueQuantity')
                    )
                    break;
                case 'BeaTypCnt':
                    this.beadTypeCount = Quantity.fromXML(
                        property.querySelector('valueQuantity')
                    )
                    break;
                case 'CapClass':
                    this.capsuleClass = property
                    .querySelector('valueCodeableConcept display')
                    .value
                    break;
                case 'CapConCnt':
                    this.capsuleConstituentCount = Quantity.fromXML(
                        property.querySelector('valueQuantity')
                    )
                    break;
                case 'Schematic':
                    this.schematic = new Attachment(
                        property.querySelector('valueAttachment')
                    )
                    break;
                case 'WgtTyp':
                    this.weightType = property
                    .querySelector('valueCodeableConcept display')
                    .value
                    break;
                case 'TotWgtNum':
                    this.totalWeightNumerator = Quantity.fromXML(
                        property.querySelector('valueQuantity')
                    )
                    break;
                case 'TotWgtDen':
                    this.totalWeightDenominator = Quantity.fromXML(
                        property.querySelector('valueQuantity')
                    )
                    break;
                case 'TotWgtTxt':
                    this.totalWeightText = property
                    .querySelector('valueMarkdown value')
                    .value
                    break;
                case "TotWgtOper":
                    this.totalWeightOperator = property
                    .querySelector('valueCodeableConcept display')
                    .value
                    break;
                default:
                    console.error('unknown property:',type)
            }
        })
        this.totals= {}
        Array.from(resultBundle.querySelectorAll("resource>Ingredient")).forEach(ingredientXML=>{
          const id = ingredientXML.querySelector(':scope>id').value
          this.totals[id] = new DrugProductComponent(ingredientXML)
        })
        this.components = {}
        const components = Array.from(xml.querySelectorAll(':scope>component')).map(componentXML=>(
            new FinishedProduct_Component(componentXML)
        ))
        components.forEach(componentClass=>{
            componentClass.constituents.forEach(constituent=>{
              constituent.ingredient = this.totals[constituent.ingredientRef]
            })
            this.components[componentClass.id] = componentClass
        })
        // testing circular references
        Object.values(this.components).forEach(component=>{
          if(component.parentId){
            component.parent = this.components[component.parentId]
            this.components[component.parentId].children.push(component)
          }
        })
    }
    get totalString(){
      if (this.totalWeightText) return this.totalWeightText;
      else{
        let returnString = ""
        if (this.totalWeightOperator) returnString+=this.totalWeightOperator
        returnString += this.totalWeightNumerator.string
        if (this.totalWeightDenominator){ returnString+="/"
          // if the denominator is one, don't print it
          if(Number(this.totalWeightDenominator.value)==1) returnString+= this.totalWeightDenominator.unit
          // else just use the string
          else returnString+=this.totalWeightDenominator.string
        }
        return returnString
      }
    }
    write(narrative){
      // property table
      narrative.add('<table>')
      if (this.overallReleaseProfile) narrative
      .add(`<tr><td>Release Profile:</td><td>${this.overallReleaseProfile}</td></tr>`)
      if (this.overallReleaseMechanism) narrative
      .add(`<tr><td>Release Mechanism:</td><td>${this.overallReleaseMechanism}</td></tr>`)
      if (this.coatingIndicator) narrative
      .add(`<tr><td>Has Coatings:</td><td>${this.coatingIndicator}</td></tr>`)
      if (this.layerCount) narrative
      .add(`<tr><td>Layer Count:</td><td>${this.layerCount.string}</td></tr>`)
      if (this.beadTypeCount) narrative
      .add(`<tr><td>Bead Type Count:</td><td>${this.beadTypeCount.string}</td></tr>`)
      if (this.capsuleClass) narrative
      .add(`<tr><td>Capsule Classification:</td><td>${this.capsuleClass}</td></tr>`)
      if (this.capsuleConstituentCount) narrative
      .add(`<tr><td>Capsule Constituent Count:</td><td>${this.capsuleConstituentCount.string}</td></tr>`)
      if (this.schematic) this.schematic.writeRow(narrative,'schematic')
      narrative.add('</table>')
      // Part table
      narrative.add('<table class="productTable">')
      narrative.add('<tr><th colspan="7">Amount by Part and Sub-part</th></tr>')
      narrative.add('<tr><th>Part/SubPart</th><th>Ingredient ID</th><th>Function</th><th>Amount (Part)</th><th>% (Part)</th><th>Amount (Total)</th><th>% (Total)</th></tr>')
      const printPart = (component,label,indent)=>{
        component.constituents.forEach((constituent,index)=>{
          const {ingredient:{substance}}=constituent
          const functionName = constituent.functionCategory==="Active Ingredient"?"Active":constituent.functionName
          narrative.add(`<tr>`)
          if (index==0) narrative.add(`<td class="partName" rowspan="${component.constituents.length}" style="padding-left: ${indent+0.5}em">${label}</td>`)
          narrative.add(`<td class="ingredientName">${substance.identifier}</td><td class="function">${functionName}</td><td>${constituent.amount.string}</td><td>${constituent.contentPercentString}</td></tr>`)
          // all the components that have a parent will appear somewhere in the children
          // of a parent
        })
        component.children.forEach(subPart=>{
          printPart(subPart,`${subPart.id}`,indent+1)
        })
        narrative.add('<tr class="total">',
        `<td class="partName" style="padding-left: ${indent+0.5}em" colspan="5">${label} subTotal</td>`,
        `<td>${component.amount.string}</td>`,
        `<td>${component.contentPercentString}</td>`,
        '</tr>')
      }
      Object.values(this.components).forEach(component=>{
        // if the component has no parents, it is not a subPart
        if(!component.parent){
          printPart(component,`${component.id}`,0)
        }
      })
      narrative.add(`<tr style="border-top: 3px double black; font-weight:bold">`,
      `<td class="left" colspan="5">Total</td><td>${this.totalString}</td><td>100</td></tr>`)
      narrative.add("</table>")
      // Ingredient Totals Table
      narrative.add('<table class="productTable">')
      narrative.add('<tr><th colspan="10">Total Ingredients</th></tr>')
       narrative.add('<tr>',
       '<th>ID</th>',
       '<th>Preferred Term</th>',
       '<th>Grade</th>',
       '<th>UNII</th>',
       '<th>Role</th>',
       '<th>Type</th>',
       '<th>Amount</th><th>%</th>',
       '<th>Organism</th>',
       '<th>Country</th>',
       '</tr>',
       )
      Object.values(this.totals).forEach(total=>{
        narrative.add('<tr>',
        `<td class="center">${total.substance.identifier}</td>`,
        `<td class="center">${total.substance.preferredTerm}</td>`,
        `<td class="center">${total.substance.grade}</td>`,
        `<td class="center">${total.substance.uniiCode||'--'}</td>`,
        `<td class="center">${total.role}</td>`,
        `<td class="center">${total.substance.sourceMaterial.type}</td>`,
        `<td>${total.strengthString}</td>`,
        `<td>${total.contentPercentString}</td>`,
        `<td class="center">${total.substance.sourceMaterialString??'--'}</td>`,
        `<td class="center">${total.substance.sourceMaterial.countryOfOrigin??'--'}</td>`,
        '</tr>'
        )
      })
      narrative.add('</table>')
    }
  }

class RoutineDrugProduct extends Resource{
  constructor(xml){
    super(xml);
      this.identifier = xml.querySelector(':scope>identifier value')?.value
      this.doseForm = xml.querySelector(':scope>combinedPharmaceuticalDoseForm display')?.value
      this.route = xml.querySelector(':scope>route display')?.value
      const names = Array.from(xml.querySelectorAll(":scope>name"));
      names.forEach((name) => {
        const type = name.querySelector("type coding code").value;
        switch (type) {
          case "NON":
            this.nonProprietaryName =
              name.querySelector("productName").value;
            break;
          case "PROP":
            this.proprietaryName = name.querySelector("productName").value;
            break;
          default:
            console.error("unknown name type:", type);
            break;
        }
      });
  }
  writeTable(narrative){
    const productTable = new BasicTable({style:'margin-bottom: 1em'})
    const rowTag = new Tag('tr')
    const tableHeader = new Tag('th',{'colspan':'2'})
    tableHeader.add('Product Details')
    rowTag.add(tableHeader)
    productTable.add(rowTag);
    if (this.nonProprietaryName) productTable.addRow('Non-Proprietary Name:',this.nonProprietaryName)
    if (this.proprietaryName) productTable.addRow('Proprietary Name:',this.proprietaryName)
    if (this.doseForm) productTable.addRow('Dose Form:',this.doseForm);
    if (this.route) productTable.addRow('Route of Administration:', this.route)
    narrative.add(productTable.html)
}
}