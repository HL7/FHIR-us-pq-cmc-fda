class SimpleOrg {
    constructor(name, city, state, country) {
      this.name = name;
      this.city = city;
      this.state = state;
      this.country = country;
    }
    get simpleName() {
      if (this.country === "United States") {
        return this.name + ", " + this.city + ", " + this.state;
      } else {
        return this.name + ", " + this.city + ", " + this.country;
      }
    }
  }
  class Organization extends SimpleOrg {
    constructor(name, lines, city, state, country, identifiers) {
      super(name, city, state, country);
      this.line1 = lines[0];
      if (lines[1]) this.line2 = lines[1];
      this.identifiers = identifiers;
    }
    static fromXML(element) {
      const name = element.querySelector("name").getAttribute("value");
      const lines = Array.from(element.querySelectorAll("line")).map((e) =>
        e.getAttribute("value")
      );
      const city = element.querySelector("city").getAttribute("value");
      // not all addresses have states
      const state =
        element.querySelector("state")?.getAttribute("value") ?? null;
      const country = element
        .querySelector("country")
        .getAttribute("value");
      const identifiers = Array.from(
        element.querySelectorAll("identifier")
      ).map((identifier) => ({
        system: identifier
          .querySelector("type>coding>display")
          .getAttribute("value"),
        value: identifier.querySelector("value").getAttribute("value"),
      }));
      return new Organization(
        name,
        lines,
        city,
        state,
        country,
        identifiers
      );
    }
    static fromReference(reference) {
      const element = Resource.findById(reference);
      return Organization.fromXML(element);
    }
  }