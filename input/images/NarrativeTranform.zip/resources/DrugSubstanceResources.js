class ComponentSubstance extends SubstanceDefinition {
    constructor (xml){
        super(xml);
        this.grade = xml.querySelector('grade display').value
    }
}
class ExcipientRaw extends SubstanceDefinition{
    constructor(xml){
        super(xml);
        this.grade = xml.querySelector('grade display').value
    }
    writeTable(narrative){
        const excipientTable = new BasicTable({style:'margin-bottom: 1em'})
        const rowTag = new Tag('tr')
        const tableHeader = new Tag('th',{'colspan':'2'})
        tableHeader.add('Substance Details')
        rowTag.add(tableHeader)
        excipientTable.add(rowTag);
        this.names.forEach(name=>{
            excipientTable.addRow(name.type,name.name)
        })
        if (this.uniiCode) excipientTable.addRow('UNII Code:',this.uniiCode)
        if (this.molecularWeight) excipientTable.addRow('Molecular Weight:',this.molecularWeight)
        if (this.classification) excipientTable.addRow('Classification:',this.classification)
        if (this.grade) excipientTable.addRow('Grade:',this.grade)
        if (this.sourceMaterialString) excipientTable.addRow('Source Material:',this.sourceMaterialString)
        if (this.molecularFormula) excipientTable.addRow("Molecular Formula:",this.molecularFormula)
        if (this.manufacturer) excipientTable.addRow("Manufacturer:",this.manufacturer.simpleName)
        if (this.supplier) excipientTable.addRow('Supplier',this.supplier.simpleName)
        narrative.add(excipientTable.html)
    }
}
// the substance info looks identical to the excipient fields?
class RoutineSubstanceDefinition extends ExcipientRaw{
    constructor(xml){
        super(xml)
    }
}