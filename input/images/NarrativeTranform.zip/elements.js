class Quantity{
    constructor(value,comparator,unit,system,code){
        this.value=value;
        this.comparator=comparator;
        this.unit=unit;
        this.system=system;
        this.code=code;
    }
    get string(){
        return `${this.comparator??""} ${this.value}${this.unit??""}`
    }
    /**
     * 
     * @param {Element} xml 
     */
    static fromXML(xml){
        const value = xml.querySelector(':scope>value').value;
        const comparator = xml.querySelector(':scope>comparator')?.value
        const unit = xml.querySelector(':scope>unit')?.value
        const system = xml.querySelector(':scope>system')?.value
        const code = xml.querySelector(':scope>code')?.value
        return new Quantity(value,comparator,unit,system,code)
    }
}
class FHIR_Range{
    constructor(low,high){
        if (low instanceof Quantity) this.low = low
        else if (low===undefined) this.low;
        else this.low = new Quantity(low.value,low.comparator,low.unit,low.system,low.code)
        if (high instanceof Quantity) this.high = high
        else if (high===undefined) this.high;
        else this.high = new Quantity(high.value,high.comparator,high.unit,high.system,high.code)
    }
    static fromXML(xml){
        const low = Quantity.fromXML(xml.querySelector('low'))
        const high = Quantity.fromXML(xml.querySelector('high'))
        return new FHIR_Range(low,high)
    }
}
class FinishedProduct_Component extends ContentPercentStringMixin(Resource){
    parent;
    children=[];
    constructor(xml){
        super();
        this.type = xml.querySelector(":scope>type display").value
        this.tabletFunction = xml.querySelector(':scope>function text')?.value
        this.amount = Quantity.fromXML(
            xml.querySelector(':scope>amount')
        )
        xml.querySelectorAll(':scope>property').forEach(property=>{
            switch (property.querySelector('type code').value) {
                case 'PPiD':
                    this.id=property
                    .querySelector('valueCodeableConcept text')
                    .value
                    break;
                case 'PPiDref':
                    this.parentId=property
                    .querySelector('valueCodeableConcept text')
                    .value
                    break;
                case 'RelsProf':
                    this.releaseProfile = property
                    .querySelector('valueCodeableConcept display')
                    .value
                    break;
                case 'RelsMech':
                    this.releaseMechanism = property
                    .querySelector('valueCodeableConcept display')
                    .value
                    break;
                case 'CoatPurpose':
                    this.coatingPurpose = property
                    .querySelector('valueCodeableConcept display')
                    .value
                    break;
                case 'Color':
                    this.color = property
                    .querySelector('valueCodeableConcept text').value
                    break;
                case 'ContPercent':
                    this.contentPercent = Quantity.fromXML(
                        xml.querySelector('valueQuantity')
                    )
                    break;
                case 'AddInfo':
                    this.additionalInfo = 
                    mdConverter.makeHtml(property
                    .querySelector('valueMarkdown').value)
                    break;
                default:
                    console.error('unknown type:',property.querySelector('type code').value)
                    break;
            }
        })
        this.constituents = Array.from(
            xml.querySelectorAll(':scope>constituent')
        ).map(constituentXML=>(
            new FinishedProduct_Constituent(constituentXML)
        ))
    }
}
class FinishedProduct_Constituent extends ContentPercentStringMixin(Resource){
    ingredient;
    constructor(xml){
        super();
        const amount = xml.querySelector('amount')
        if (amount) this.amount = Quantity.fromXML(amount)
        this.group_layer = xml.querySelector('location text')?.value
        this.location = xml.querySelector('location text')?.value
        const ref = xml.querySelector('reference reference').value
        this.ingredientRef = ref.split('/')[1] ?? ref.split('urn:uuid:')[1] ?? ref
        xml.querySelectorAll(':scope>function').forEach(f=>{
            switch (f.querySelector('version').value) {
                case 'function':
                    this.functionName = f.querySelector('display').value
                    break;
                case 'category':
                    this.functionCategory= f.querySelector('display').value
                    break;
                default:
                    console.error('unknown function:',f.querySelector('version').value)
                    break;
            }
        })
        this.contentPercent = xml.querySelector(':scope>extension valueDecimal')?.value
    }
}
class DrugProductComponent extends ContentPercentStringMixin(Resource) {
    constructor(xml){
        super(xml);
        this.status = xml.querySelector(':scope>status').value
        this.role = xml.querySelector(':scope>role display').value
        this.substanceRef = xml.querySelector('substance>code>reference>reference').value
        this.substance = ComponentSubstance.fromReference(this.substanceRef)
        this.strengthType = xml.querySelector('extension[url="strengthType"] display').value
        this.contentPercent = xml.querySelector('extension[url="contentPercent"] valueDecimal').value
        this.strengthOperator = xml.querySelector('extension[url="strengthOperator"] display')?.value
        this.textPresentation=xml.querySelector('strength>textPresentation').value
        if(xml.querySelector('presentationRatio')){
            this.strengthNumerator = Quantity.fromXML(xml.querySelector('numerator'))
            this.strengthDenominator = Quantity.fromXML(xml.querySelector('denominator'))
        }else if (xml.querySelector('presentationQuantity')){
            this.strengthNumerator = Quantity.fromXML(xml.querySelector('presentationQuantity'))
        } else {
            console.error('No Ratio or Quantity?')
        }
    }
    get strengthString(){
        if (this.textPresentation) return this.textPresentation;
        else{
          let returnString = ""
          if (this.strengthOperator) returnString+=this.strengthOperator
          returnString += this.strengthNumerator.string
          if (this.strengthDenominator){ returnString+="/"
            // if the denominator is one, don't print it
            if(Number(this.strengthDenominator.value)==1) returnString+= this.totalWeightDenominator.unit
            // else just use the string
            else returnString+=this.totalWeightDenominator.string
          }
          return returnString
        }
      }
}
class Attachment extends Resource {
    constructor(xml) {
      super();
      this.contentType = xml.querySelector("contentType")?.value;
      this.base64Data = xml.querySelector("data")?.value;
      this.title = xml.querySelector("title")?.value;
    }
    writeRow(narrative,name,className){
      narrative.add('<tr>')
      if (className) narrative.add(`<td class="${className}">${name}</td>`) 
      else narrative.add(`<td>${name}</td>`)
      if (
          ["image/png", "image/jpeg", "image/svg+xml"].includes(
            this.contentType
          )
        ) {
          narrative.add(`<td><img class="narrative" src="data:${this.contentType};base64,${this.base64Data}"/></td></tr>`);
        } else
          narrative.add(`<td><a href="data:${this.contentType};base64,${this.base64Data}" download="${this.title}">${this.title}</a></td></tr>`);
      }
  }
  
  class Base64Document extends Attachment {
    /**
     *
     * @param {Element} xml
     */
    constructor(xml) {
      super(xml.querySelector("attachment"));
      this.status = xml.querySelector("status")?.value;
    }
    }
