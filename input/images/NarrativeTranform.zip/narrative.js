class Narrative{
    /**
     * html must be kept as a string, it cannot be put in DOM and
     * pulled out after, for whatever reason it will not close image
     * tags (even if the string creating the element has a close tag)
     * which is not valid as xhtml
     */
    #html = "";
    add(...data){
        this.#html+=data.flat().join('');
    }
    get html(){
        return this.#html.replace(/\n */gm,'')
    }
}
class Tag{
    children=[]
    constructor(name,attributes={}){
        this.name = name,
        this.attributes = attributes
    }
    get html(){
        if (this.children.length>0){
            return [`<${this.name}`,
            Object.entries(this.attributes).map(([name,value])=>` ${name}="${value}"`),
            `>`,
            this.children.flat(Infinity).map(child=>{
                if (child instanceof Tag) return child.html
                else return child
            }),
            `</${this.name}>`].flat(Infinity).join('')
        }else{
            return [`<${this.name}`,
            Object.entries(this.attributes).map(([name,value])=>` ${name}="${value}"`),
            `/>`].join('')
        }
    }
    add(...data){
        this.children.push(...data)
    }
}
class BasicTable extends Tag{
    constructor(attributes){
        super('table',attributes)
    }
    addRow(...columns){
        this.add(`<tr>`,
        columns.map((column)=>{
        
        if (column instanceof Tag && column.name === 'td') return column
        else {
            const cellTag = new Tag('td')
            cellTag.add(column)
            return cellTag
        }
        
        }),
        `</tr>`)
    }
    addHeader(...columns){
        const row = new Tag('tr')
        columns.forEach(value=>{
            const column = new Tag('th')
            column.add(value)
            row.add(column)
        })
        this.add(row)
    }
}