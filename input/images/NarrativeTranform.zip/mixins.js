const ErrorMessages = Object.freeze({
    nan: new Error('Content Percent is Not a Number'),
    outOfRange: new Error('Content Percent is not in the range 0-1'),
    noPoint: new Error("Content Percent doesn't have a decimal point"),
    noDecimals: new Error("There are no digits after the decimal point")
})
/**
 * adds a getter to format the contentPercent into a percentage.
 * Needs to be done this way instead of just class inheritance because
 * contentPercent does not have a fixed path for each of the resources
 * it appears in
 * @param {Class} superclass 
 * @returns {Class}
 */
const ContentPercentStringMixin =(superclass) => {
    return class extends superclass{
        get contentPercentString(){
        // contentPercent is a decimal between 0 and 1
        // stored as a string; it cannot be converted to 
        // Number because JS has no concept of significant
        // figures and will either get rid of trailing 
        // zeroes or end up with floating point error
        // and have way too many digits

        const contentPercent = (()=>{
            // contentPercent may represent a quantity 
            // or a decimal. if it's a quantity, get the
            // value out of it.
            if (this.contentPercent instanceof Quantity){
                return String(this.contentPercent.value)
            } else return this.contentPercent
        })()
        // if it's not a decimal error out
        console.log(this)
        if (isNaN(Number(contentPercent))) throw ErrorMessages.nan
        if (Number(contentPercent)>1||Number(contentPercent)<0) {
            throw ErrorMessages.outOfRange
        }
        // 0 or 1 edge cases -- everything else will have a '.'
        if (Number(contentPercent)==0) return '0'
        if (Number(contentPercent)==1) return '100'
        if (!contentPercent.includes('.')){
            throw ErrorMessages.noPoint
        }
        const decimal=contentPercent.split('.')[1]
        if (decimal.length === 0) throw ErrorMessages.noDecimals
        // decimal at this point is a string of digits
        let returnString = ""
        if (decimal.length === 1){
            // this came from something in the form '0.x'
            returnString = decimal+'0' // just 'x0', i.e 0.5 => 50
        }else
        if (decimal.length === 2){
            // this came from something in the form '0.xy'
            returnString = decimal // just 'xy'
        }
        else{
            // anything else. came from something like '0.xy....z'
            // take the first two digits, add a decimal point, then add the rest
            returnString = decimal.slice(0,2)+'.'+decimal.slice(2)
        }
        // check if the first number was a 0 i.e it came from something like 0.0xyz
        // if so chop it off
        if(returnString[0]==='0') returnString = returnString.slice(1)
        return returnString
    }
}}