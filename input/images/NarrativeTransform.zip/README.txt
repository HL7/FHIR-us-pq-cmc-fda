Copyright (C) 2023, 2024 (Catherine Hosage Norman, Christopher Norman, Module 3 Solutions, LLC)
Markdown conversion excerpted from Showdown, a JavaScript Markdown to HTML converter,
based on the original works by John Gruber.

Reader.js is published under the terms of HL7's FHIR license. http:hl7.org/fhir/license.html
Creative Commons "No Rights Reserved" (CC0)

Portions were adapted from eStability.xsl transforms PORT_IN090001UV02.xsd into HTML 
   Copyright (C) 2009, 2012, 2013 (Catherine Hosage Norman, Module 3 Solutions, LLC) 
   It was also commissioned by the FDA.
	
Revisions:
   2023-12-20: Initial version commissioned by the FDA
   2023-12-22: Support for version 0.1.18 of PQ/CMC IG and minimized to one file
   2024-01-01: Fixed bug where acceptance criteria of sub-tests in quality specifications weren't assigned
   2024-01-10: Fixed bug where representations weren't being displayed in 32S10 because a flag wasn't being set
               MOLFILE structural representations now appear as a download instead of raw data
   2024-03-02: Updated for version 0.1.20 of PQ/CMC IG.
   2024-03-05: Updated for new IG path (fhir/us/pq-cmc -> fhir/us/pq-cmc-fda)
               Updated 32S23 to display a table for its subject
   2024-03-27: Fixed bug where an extra close tag caused 32p10 to break
   2024-03-28: added row for excipients with a country of origin
   2024-03-30: updated for new specification approval status path (useContext.valueCodeableConcept>type.coding)
   2024-08-25: update for stage 2 bundles and updated the stage 1 bundles to 1.1.4
   2024-08-29: Update text to reflect the new bundles it supports, version changed to 1.1.6
   2023-09-16: added 3.2.S.3.2. Previously was not displaying
               Updated how structure data is represented in every SubstanceDefinition-derived profile to be
               more similar to characterization data.
               Rewrote much of how tags are stored internally to hopefully produce narratives that are
               validator-safe. Markdown fields with ampersands and quotes will most likely fail validation
               due to quirks with xml escape characters and the DOM replacing them.

Instructions:
Open Transform.html in a browser. The page displays.

Click on “Choose file” then select at file. The Narrative Transform detects the bundle type. 
All bundles in this IG are supported.
The Narrative Transform does not validate. If nothing displays, a error message appears. Check the XML file.
The tranformed XML file will show in the text area. Verrify that this is the file and save the updated file 
by clicking the “Save XML Button file” at the bottom of the page. Scroll down if necessary to see the button. 
Enter a new file name.
Confirm by clicking “OK”. 

Note: Due to Cross-Origin Resource Sharing (CORS), the phrase “This page says” cannot be changed.
To process another file, simply open another file

