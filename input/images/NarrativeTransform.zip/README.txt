Copyright (C) 2023 (Catherine Hosage Norman, Christopher Norman, Module 3 Solutions, LLC)
Markdown conversion excerpted from Showdown, a JavaScript Markdown to HTML converter,
based on the original works by John Gruber.

Reader.js is published under the terms of HL7's FHIR license. http:hl7.org/fhir/license.html
Creative Commons "No Rights Reserved" (CC0)

Portions were addapted from eStability.xsl transforms PORT_IN090001UV02.xsd into HTML 
   Copyright (C) 2009, 2012, 2013 (Catherine Hosage Norman, Module 3 Solutions, LLC) 
   It was also commissioned by the FDA.
	
Revisions:
   2023-12-20: Initial version commissioned by the FDA
   2023-12-22: Support for version 0.1.18 of PQ/CMC IG and minimized to one file
   2024-01-01: Fixed bug where acceptance criteria of sub-tests in quality specifications weren't assigned
   2024-01-10: Fixed bug where representations weren't being displayed in 32S10 because a flag wasn't being set
   2024-01-11: Replaced style tags with inline styles everywhere so the file will validate after being styled,
               replaced header tags and download attributes for the same reason
Instructions:
Open Transform.html in a browser. The page displays.

Click on “Choose file” then select at file. The Narrative Transform detects the bundle type. 
All bundles in this IG are supported.
The Narrative Transform does not validate. If nothing displays, a error message appears. Check the XML file.
The tranformed XML file will show in the text area. Verrify that this is the file and save the updated file 
by clicking the “Save XML Button file” at the bottom of the page. Scroll down if necessary to see the button. 
Enter a new file name.
Confirm by clicking “OK”. 

Note: Due to Cross-Origin Resource Sharing (CORS), the phrase “This page says” cannot be changed.
To process another file, simply open another file

